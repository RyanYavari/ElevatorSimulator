package HW2;

public class ElevatorTest {
	
	public static void main(String[] args) {
		Elevator mcQuarryHall = new Elevator();
		mcQuarryHall.board(2);
		mcQuarryHall.board(5);
		mcQuarryHall.board(3);
		
		System.out.println(mcQuarryHall);
		
		mcQuarryHall.go();
		mcQuarryHall.go();
		mcQuarryHall.go();
		mcQuarryHall.go();
		
		
		
		

	
		
        }
	}


