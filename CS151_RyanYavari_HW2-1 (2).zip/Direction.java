package HW2;

public enum Direction {
	
	UP, DOWN;

}
